package com.sadcubeapps.easynotification

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.NotificationCompat
import com.google.android.gms.ads.InterstitialAd
import androidx.databinding.DataBindingUtil
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.MobileAds
import com.sadcubeapps.easynotification.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var mInterstitialAd: InterstitialAd

    private val sharedPrefFile = "EasyNotificationSadCubeApps"
    private lateinit var sharedPreferences: SharedPreferences

    private lateinit var activityMainBinding: ActivityMainBinding



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        MobileAds.initialize(this, getString(R.string.admob_app_id))
        mInterstitialAd = InterstitialAd(this)
        mInterstitialAd.adUnitId = getString(R.string.test_ad_id)

        mInterstitialAd.adListener = object : AdListener() {
            override fun onAdLoaded() {
                mInterstitialAd.show()
                super.onAdLoaded()
            }
        }

        sharedPreferences = this.getSharedPreferences(sharedPrefFile, Context.MODE_PRIVATE)




    }

    override fun onSaveInstanceState(outState: Bundle) {

        outState.putString("balance", "")
        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        val balance = savedInstanceState.getString("balance")
    }
}